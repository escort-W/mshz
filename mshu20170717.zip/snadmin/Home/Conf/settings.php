<?php return array (
  'admin_users' => 
  array (
    0 => 'admin@qq.com',
  ),
  'withdraw_day_diff' => '15',
  'knock_out_day_diff' => '30',
  'supply_money_upper_limit' => '60000',
  'supply_money_lower_limit' => '100',
  'tjr_share' => '10',
  'jl_share' => 
  array (
    1 => '5',
    2 => '3',
    3 => '1',
    4 => '0.5',
    5 => '0.3',
    6 => '0.1',
    7 => '0.05',
    8 => '0.03',
    9 => '0.01',
  ),
); ?>
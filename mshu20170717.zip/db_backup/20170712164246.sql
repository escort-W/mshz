-- MySQL dump 10.13  Distrib 5.5.53, for Win32 (AMD64)
--
-- Host: localhost    Database: mshz
-- ------------------------------------------------------
-- Server version	5.5.53

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ot_apply`
--

DROP TABLE IF EXISTS `ot_apply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_apply` (
  `AL_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '用户申请表',
  `AL_type` varchar(30) DEFAULT '' COMMENT '数据类型',
  `AL_time` datetime DEFAULT NULL COMMENT '提交时间',
  `AL_replyTime` datetime DEFAULT NULL COMMENT '回复时间，管理员处理时间',
  `AL_dataID` int(11) DEFAULT '0' COMMENT '与其它表关联ID',
  `AL_userID` int(11) DEFAULT '0' COMMENT '与用户表关联ID',
  `AL_userName` varchar(50) DEFAULT '' COMMENT '申请用户名，管理列表显示',
  `AL_contact` text COMMENT '联系方式，管理列表显示第一个',
  `AL_userInfo` text COMMENT '用户其它相关信息',
  `AL_subIP` varchar(50) DEFAULT NULL COMMENT '信息提交IP',
  `AL_otherInfo` text COMMENT '其它信息',
  `AL_note` text COMMENT '申请说明',
  `AL_reply` text COMMENT '管理员备注信息',
  `AL_status` smallint(1) DEFAULT '0' COMMENT '处理状态，0-未处理，1-已处理',
  PRIMARY KEY (`AL_ID`),
  KEY `MA_dataID` (`AL_dataID`),
  KEY `MA_ID` (`AL_ID`),
  KEY `MA_userID` (`AL_userID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_apply`
--

LOCK TABLES `ot_apply` WRITE;
/*!40000 ALTER TABLE `ot_apply` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_apply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_attribute`
--

DROP TABLE IF EXISTS `ot_attribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_attribute` (
  `AB_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '商品属性-商品类型',
  `AB_atid` int(11) DEFAULT '0' COMMENT '商品类型ID，attrtype',
  `AB_theme` varchar(200) DEFAULT '' COMMENT '名称',
  `AB_rank` int(11) DEFAULT '0',
  `AB_status` smallint(1) DEFAULT '1',
  `AB_editMode` smallint(1) DEFAULT '0' COMMENT '属性编辑方式',
  `AB_values` text COMMENT '属性可选值列表',
  PRIMARY KEY (`AB_ID`),
  UNIQUE KEY `IM_ID` (`AB_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_attribute`
--

LOCK TABLES `ot_attribute` WRITE;
/*!40000 ALTER TABLE `ot_attribute` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_attribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_backupdatabase`
--

DROP TABLE IF EXISTS `ot_backupdatabase`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_backupdatabase` (
  `BD_ID` int(11) NOT NULL AUTO_INCREMENT,
  `BD_time` datetime DEFAULT NULL,
  `BD_type` varchar(25) DEFAULT NULL,
  `BD_filePartNum` smallint(6) DEFAULT NULL,
  `BD_filePath` varchar(200) DEFAULT NULL,
  `BD_fileSize` int(11) DEFAULT '0',
  `BD_tableStr` varchar(4000) DEFAULT NULL,
  `BD_note` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`BD_ID`),
  KEY `BB_ID` (`BD_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_backupdatabase`
--

LOCK TABLES `ot_backupdatabase` WRITE;
/*!40000 ALTER TABLE `ot_backupdatabase` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_backupdatabase` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_drrz`
--

DROP TABLE IF EXISTS `ot_drrz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_drrz` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime DEFAULT NULL,
  `ip` varchar(60) DEFAULT NULL,
  `user` varchar(60) DEFAULT NULL,
  `leixin` int(8) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15615 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_drrz`
--

LOCK TABLES `ot_drrz` WRITE;
/*!40000 ALTER TABLE `ot_drrz` DISABLE KEYS */;
INSERT INTO `ot_drrz` VALUES (15607,'2017-07-11 11:58:05','1.193.126.112','admin',1),(15608,'2017-07-11 12:02:00','1.193.126.112','admin',1),(15609,'2017-07-11 16:34:10','1.193.126.112','admin',1),(15610,'2017-07-11 17:56:38','','15737168980',0),(15611,'2017-07-11 18:23:56','1.193.126.112','admin',1),(15612,'2017-07-11 18:25:19','','15136272070',0),(15613,'2017-07-12 09:01:35','','15136272070',0),(15614,'2017-07-12 09:04:30','115.60.190.208','admin',1);
/*!40000 ALTER TABLE `ot_drrz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_font`
--

DROP TABLE IF EXISTS `ot_font`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_font` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reg_num` varchar(255) DEFAULT '0' COMMENT '注册人数',
  `user_up` int(11) DEFAULT '0' COMMENT '在线人数',
  `apply_money` int(11) DEFAULT '0' COMMENT '提供帮助金额',
  `need_money` int(11) DEFAULT '0' COMMENT '需求金额',
  `trade_num` int(11) DEFAULT '0' COMMENT '成功交易订单数',
  `up_time` int(11) DEFAULT '0' COMMENT '更改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_font`
--

LOCK TABLES `ot_font` WRITE;
/*!40000 ALTER TABLE `ot_font` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_font` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_info`
--

DROP TABLE IF EXISTS `ot_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_info` (
  `IF_ID` int(11) NOT NULL AUTO_INCREMENT,
  `IF_time` datetime NOT NULL,
  `IF_revTime` datetime DEFAULT NULL,
  `IF_type` varchar(50) DEFAULT NULL,
  `IF_type1ID` int(11) DEFAULT '0',
  `IF_type2ID` int(11) DEFAULT '0',
  `IF_theme` varchar(250) DEFAULT NULL,
  `IF_webImg` varchar(255) DEFAULT '',
  `IF_content` longtext,
  `IF_rank` int(11) DEFAULT '0',
  `IF_readNum` int(11) DEFAULT '0',
  `IF_isIndex` smallint(1) DEFAULT '0',
  `IF_seodesc` longtext,
  `IF_seokeyword` longtext,
  `zt` int(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`IF_ID`),
  KEY `IF_ID` (`IF_ID`),
  KEY `IF_menu1` (`IF_type1ID`),
  KEY `IF_readNum` (`IF_readNum`),
  KEY `IF_type1ID` (`IF_type`)
) ENGINE=MyISAM AUTO_INCREMENT=126 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_info`
--

LOCK TABLES `ot_info` WRITE;
/*!40000 ALTER TABLE `ot_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_ip`
--

DROP TABLE IF EXISTS `ot_ip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_ip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(255) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `leixin` varchar(255) NOT NULL DEFAULT '0',
  `user` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_ip`
--

LOCK TABLES `ot_ip` WRITE;
/*!40000 ALTER TABLE `ot_ip` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_ip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_jsbz`
--

DROP TABLE IF EXISTS `ot_jsbz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_jsbz` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `zffs1` int(8) NOT NULL DEFAULT '0',
  `zffs2` int(8) NOT NULL DEFAULT '0',
  `zffs3` int(8) NOT NULL DEFAULT '0',
  `jb` decimal(15,0) NOT NULL DEFAULT '0',
  `zt` int(8) NOT NULL DEFAULT '0',
  `user` varchar(255) DEFAULT NULL,
  `qr_zt` int(8) DEFAULT '0',
  `user_tjr` varchar(255) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `user_nc` varchar(255) DEFAULT NULL,
  `qb` int(8) NOT NULL DEFAULT '0',
  `date1` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=903784 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_jsbz`
--

LOCK TABLES `ot_jsbz` WRITE;
/*!40000 ALTER TABLE `ot_jsbz` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_jsbz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_link`
--

DROP TABLE IF EXISTS `ot_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_link` (
  `LN_ID` int(11) NOT NULL AUTO_INCREMENT,
  `LN_type` varchar(20) NOT NULL,
  `LN_theme` varchar(200) DEFAULT NULL,
  `LN_rank` int(11) DEFAULT '0',
  `LN_state` smallint(1) DEFAULT '1',
  `LN_imgMode` varchar(20) DEFAULT NULL,
  `LN_imgUrl` varchar(200) DEFAULT NULL,
  `LN_webUrl` varchar(200) DEFAULT NULL,
  `LN_time` datetime DEFAULT NULL,
  PRIMARY KEY (`LN_ID`),
  UNIQUE KEY `IM_ID` (`LN_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_link`
--

LOCK TABLES `ot_link` WRITE;
/*!40000 ALTER TABLE `ot_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_logusers`
--

DROP TABLE IF EXISTS `ot_logusers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_logusers` (
  `LU_ID` int(11) NOT NULL AUTO_INCREMENT,
  `LU_time` datetime DEFAULT NULL,
  `LU_userName` varchar(35) DEFAULT NULL,
  `LU_userID` int(11) DEFAULT '0',
  `LU_type` varchar(35) DEFAULT NULL,
  `LU_note` longtext,
  PRIMARY KEY (`LU_ID`),
  KEY `LU_ID` (`LU_ID`),
  KEY `LU_userID` (`LU_userID`),
  KEY `LU_userID1` (`LU_userName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_logusers`
--

LOCK TABLES `ot_logusers` WRITE;
/*!40000 ALTER TABLE `ot_logusers` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_logusers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_match`
--

DROP TABLE IF EXISTS `ot_match`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_match` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `supply_timelimit` int(11) DEFAULT '0',
  `accept_timelimit` int(11) DEFAULT '0',
  `math_switch` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_match`
--

LOCK TABLES `ot_match` WRITE;
/*!40000 ALTER TABLE `ot_match` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_match` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_member`
--

DROP TABLE IF EXISTS `ot_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_member` (
  `MB_ID` int(11) NOT NULL AUTO_INCREMENT,
  `MB_time` date DEFAULT NULL,
  `MB_loginTime` datetime DEFAULT NULL,
  `MB_loginNum` int(11) DEFAULT '0',
  `MB_loginIP` varchar(20) DEFAULT NULL,
  `MB_realname` varchar(30) DEFAULT NULL,
  `MB_username` varchar(30) NOT NULL,
  `MB_userpwd` varchar(32) NOT NULL,
  `MB_userKey` varchar(36) DEFAULT NULL,
  `MB_right` int(11) DEFAULT '20',
  `MB_userGroup` int(11) DEFAULT '0',
  `MB_rightStr` longtext,
  `MB_itemNum` int(11) DEFAULT '20',
  `MB_rights` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT '' COMMENT '权限',
  PRIMARY KEY (`MB_ID`),
  KEY `MB_itemNum` (`MB_itemNum`),
  KEY `MB_loginNum` (`MB_loginNum`),
  KEY `MB_userKey` (`MB_userKey`)
) ENGINE=MyISAM AUTO_INCREMENT=2034 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_member`
--

LOCK TABLES `ot_member` WRITE;
/*!40000 ALTER TABLE `ot_member` DISABLE KEYS */;
INSERT INTO `ot_member` VALUES (1,NULL,NULL,0,NULL,NULL,'admin','e10adc3949ba59abbe56e057f20f883e',NULL,1,0,NULL,20,'');
/*!40000 ALTER TABLE `ot_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_memberlog`
--

DROP TABLE IF EXISTS `ot_memberlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_memberlog` (
  `ML_ID` int(11) NOT NULL AUTO_INCREMENT,
  `ML_time` datetime NOT NULL,
  `ML_date` date NOT NULL,
  `ML_userID` int(11) NOT NULL,
  `ML_realname` varchar(30) NOT NULL,
  `ML_ip` varchar(20) NOT NULL,
  `ML_ipCN` varchar(50) NOT NULL,
  `ML_menuFileID` mediumint(9) NOT NULL DEFAULT '0',
  `ML_note` varchar(255) DEFAULT NULL,
  `ML_readNum` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ML_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=243 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_memberlog`
--

LOCK TABLES `ot_memberlog` WRITE;
/*!40000 ALTER TABLE `ot_memberlog` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_memberlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_menufile`
--

DROP TABLE IF EXISTS `ot_menufile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_menufile` (
  `MF_ID` int(11) NOT NULL AUTO_INCREMENT,
  `MF_level` int(11) DEFAULT '0',
  `MF_fileID` int(11) DEFAULT '0',
  `MF_theme` varchar(50) DEFAULT NULL,
  `MF_fileName` varchar(35) DEFAULT NULL,
  `MF_getMudi` varchar(16) DEFAULT NULL,
  `MF_example` varchar(160) DEFAULT NULL,
  `MF_rank` int(11) DEFAULT '0',
  `MF_note` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`MF_ID`),
  KEY `MF_fileID` (`MF_fileID`),
  KEY `MF_ID` (`MF_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=105 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_menufile`
--

LOCK TABLES `ot_menufile` WRITE;
/*!40000 ALTER TABLE `ot_menufile` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_menufile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_menutree`
--

DROP TABLE IF EXISTS `ot_menutree`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_menutree` (
  `MT_ID` int(11) NOT NULL AUTO_INCREMENT,
  `MT_level` int(11) DEFAULT '0',
  `MT_menuID` int(11) DEFAULT '0',
  `MT_fileID` int(11) DEFAULT '0',
  `MT_theme` varchar(50) DEFAULT NULL,
  `MT_fileName` varchar(25) DEFAULT NULL,
  `MT_getMudi` varchar(20) DEFAULT NULL,
  `MT_getDataMode` varchar(50) DEFAULT NULL,
  `MT_getDataModeStr` varchar(50) DEFAULT NULL,
  `MT_getDataType` varchar(20) DEFAULT NULL,
  `MT_getDataTypeCN` varchar(50) DEFAULT NULL,
  `MT_getDataType2` varchar(20) DEFAULT NULL,
  `MT_getDataID` int(11) DEFAULT '0',
  `MT_getImgSize` varchar(60) DEFAULT '',
  `MT_getImgSize2` varchar(60) DEFAULT '',
  `MT_getOthers` varchar(160) DEFAULT NULL,
  `MT_URL` varchar(200) DEFAULT NULL,
  `MT_rank` int(11) DEFAULT '0',
  `MT_state` int(11) DEFAULT '0',
  PRIMARY KEY (`MT_ID`),
  KEY `MT_fileID` (`MT_fileID`),
  KEY `MT_ID` (`MT_ID`),
  KEY `MT_menuID` (`MT_menuID`)
) ENGINE=MyISAM AUTO_INCREMENT=166 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_menutree`
--

LOCK TABLES `ot_menutree` WRITE;
/*!40000 ALTER TABLE `ot_menutree` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_menutree` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_message`
--

DROP TABLE IF EXISTS `ot_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_message` (
  `MA_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '前台提交信息，留言、申请等',
  `MA_type` varchar(30) DEFAULT '' COMMENT '数据类型',
  `MA_theme` varchar(60) DEFAULT '' COMMENT '留言主题',
  `MA_time` datetime DEFAULT NULL COMMENT '提交时间',
  `MA_replyTime` datetime DEFAULT NULL COMMENT '回复时间',
  `MA_dataID` int(11) DEFAULT '0' COMMENT '与其它表关联ID',
  `MA_userID` int(11) DEFAULT '0' COMMENT '与用户表关联ID',
  `MA_userName` varchar(50) DEFAULT '' COMMENT '留言用户名，管理列表显示',
  `MA_contact` text COMMENT '联系方式',
  `MA_userInfo` text COMMENT '用户其它相关信息',
  `MA_subIP` varchar(50) DEFAULT NULL COMMENT '信息提交IP',
  `MA_otherInfo` text COMMENT '其它信息',
  `MA_note` text COMMENT '用户留言内容',
  `MA_reply` text COMMENT '管理员回复内容',
  `MA_status` smallint(1) DEFAULT '0' COMMENT '审核状态',
  `zt` int(8) NOT NULL DEFAULT '0',
  `pic` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`MA_ID`),
  KEY `MA_dataID` (`MA_dataID`),
  KEY `MA_ID` (`MA_ID`),
  KEY `MA_userID` (`MA_userID`)
) ENGINE=MyISAM AUTO_INCREMENT=96 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_message`
--

LOCK TABLES `ot_message` WRITE;
/*!40000 ALTER TABLE `ot_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_mobmsgset`
--

DROP TABLE IF EXISTS `ot_mobmsgset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_mobmsgset` (
  `SYS_ID` int(11) NOT NULL AUTO_INCREMENT,
  `SYS_theme` varchar(100) DEFAULT NULL,
  `SYS_address` varchar(200) DEFAULT NULL,
  `SYS_postCode` varchar(50) DEFAULT NULL,
  `SYS_contact` varchar(50) DEFAULT '',
  `SYS_mobile` varchar(50) DEFAULT '',
  `SYS_mail` varchar(80) DEFAULT NULL,
  `SYS_phone` varchar(50) DEFAULT NULL,
  `SYS_hotPhone` varchar(50) DEFAULT NULL,
  `SYS_fax` varchar(50) DEFAULT NULL,
  `SYS_qq` varchar(30) DEFAULT NULL,
  `SYS_banquan` varchar(100) DEFAULT NULL,
  `SYS_seoTitle` varchar(300) DEFAULT '',
  `SYS_seoWord` text,
  `SYS_seoDesc` text,
  PRIMARY KEY (`SYS_ID`),
  KEY `SYS_postCode` (`SYS_postCode`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_mobmsgset`
--

LOCK TABLES `ot_mobmsgset` WRITE;
/*!40000 ALTER TABLE `ot_mobmsgset` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_mobmsgset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_pdb`
--

DROP TABLE IF EXISTS `ot_pdb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_pdb` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `UE_id` int(8) DEFAULT NULL,
  `UE_account` varchar(50) DEFAULT NULL,
  `give_time` datetime DEFAULT NULL,
  `UE_theme` varchar(50) DEFAULT NULL,
  `UE_pdb` int(8) DEFAULT NULL,
  `UE_type` varchar(255) NOT NULL,
  `UE_type_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=154 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_pdb`
--

LOCK TABLES `ot_pdb` WRITE;
/*!40000 ALTER TABLE `ot_pdb` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_pdb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_pin`
--

DROP TABLE IF EXISTS `ot_pin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_pin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(255) NOT NULL,
  `pin` varchar(255) DEFAULT NULL,
  `zt` varchar(255) DEFAULT NULL,
  `sc_date` datetime DEFAULT NULL,
  `sy_user` varchar(255) NOT NULL DEFAULT '0',
  `sy_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_pin`
--

LOCK TABLES `ot_pin` WRITE;
/*!40000 ALTER TABLE `ot_pin` DISABLE KEYS */;
INSERT INTO `ot_pin` VALUES (1,'15737168980','3268a97aee0f4e498b02cf3308580680','0','2017-07-11 17:57:58','0',NULL),(2,'15737168980','0808a8fdcd20bf1769954b0e6fbcb76a','1','2017-07-11 17:57:58','15136272070','2017-07-11 18:23:18');
/*!40000 ALTER TABLE `ot_pin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_ppdd`
--

DROP TABLE IF EXISTS `ot_ppdd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_ppdd` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `p_id` varchar(255) DEFAULT NULL,
  `g_id` varchar(255) DEFAULT NULL,
  `jb` decimal(15,0) DEFAULT NULL,
  `p_user` varchar(255) DEFAULT NULL,
  `g_user` varchar(255) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `zt` int(8) NOT NULL DEFAULT '0',
  `pic` varchar(255) DEFAULT NULL,
  `zffs1` int(8) DEFAULT NULL,
  `zffs2` int(8) DEFAULT NULL,
  `zffs3` int(8) DEFAULT NULL,
  `ts_zt` int(8) NOT NULL DEFAULT '0',
  `date_hk` datetime DEFAULT NULL,
  `pic2` varchar(255) DEFAULT NULL,
  `date_hk1` datetime DEFAULT NULL,
  `date1` datetime DEFAULT NULL,
  `cold_status` int(2) unsigned DEFAULT '0',
  `zhh` int(2) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=929110 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_ppdd`
--

LOCK TABLES `ot_ppdd` WRITE;
/*!40000 ALTER TABLE `ot_ppdd` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_ppdd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_ppdd_ly`
--

DROP TABLE IF EXISTS `ot_ppdd_ly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_ppdd_ly` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ppdd_id` int(14) DEFAULT NULL,
  `user` varchar(14) DEFAULT NULL,
  `nr` text,
  `date` datetime DEFAULT NULL,
  `user_nc` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=188 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_ppdd_ly`
--

LOCK TABLES `ot_ppdd_ly` WRITE;
/*!40000 ALTER TABLE `ot_ppdd_ly` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_ppdd_ly` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_retrieve_token`
--

DROP TABLE IF EXISTS `ot_retrieve_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_retrieve_token` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `user_email` varchar(255) DEFAULT NULL,
  `token` varchar(48) DEFAULT NULL,
  `expire_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_retrieve_token`
--

LOCK TABLES `ot_retrieve_token` WRITE;
/*!40000 ALTER TABLE `ot_retrieve_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_retrieve_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_rwfb`
--

DROP TABLE IF EXISTS `ot_rwfb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_rwfb` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) unsigned DEFAULT NULL,
  `name` varchar(60) DEFAULT NULL,
  `title` varchar(60) DEFAULT NULL,
  `content` text,
  `old_price` int(11) DEFAULT '0',
  `price` int(10) DEFAULT '0',
  `zt` enum('0','1','2','3','4') DEFAULT NULL,
  `imagepath` text,
  `addtime` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=57 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_rwfb`
--

LOCK TABLES `ot_rwfb` WRITE;
/*!40000 ALTER TABLE `ot_rwfb` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_rwfb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_rwmx`
--

DROP TABLE IF EXISTS `ot_rwmx`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_rwmx` (
  `MA_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '前台提交信息，留言、申请等',
  `MA_type` varchar(30) DEFAULT '' COMMENT '数据类型',
  `MA_theme` varchar(60) DEFAULT '' COMMENT '留言主题',
  `MA_time` datetime DEFAULT NULL COMMENT '提交时间',
  `MA_replyTime` datetime DEFAULT NULL COMMENT '回复时间',
  `MA_dataID` int(11) DEFAULT '0' COMMENT '与其它表关联ID',
  `MA_userID` int(11) DEFAULT '0' COMMENT '与用户表关联ID',
  `MA_userName` varchar(50) DEFAULT '' COMMENT '留言用户名，管理列表显示',
  `MA_contact` text COMMENT '联系方式',
  `MA_userInfo` text COMMENT '用户其它相关信息',
  `MA_subIP` varchar(50) DEFAULT NULL COMMENT '信息提交IP',
  `MA_otherInfo` text COMMENT '其它信息',
  `MA_note` text COMMENT '用户留言内容',
  `MA_reply` text COMMENT '管理员回复内容',
  `MA_status` smallint(1) DEFAULT '0' COMMENT '审核状态',
  `zt` int(8) NOT NULL DEFAULT '0',
  `pic` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`MA_ID`),
  KEY `MA_dataID` (`MA_dataID`),
  KEY `MA_ID` (`MA_ID`),
  KEY `MA_userID` (`MA_userID`)
) ENGINE=MyISAM AUTO_INCREMENT=71 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_rwmx`
--

LOCK TABLES `ot_rwmx` WRITE;
/*!40000 ALTER TABLE `ot_rwmx` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_rwmx` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_service`
--

DROP TABLE IF EXISTS `ot_service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_service` (
  `SV_ID` int(11) NOT NULL AUTO_INCREMENT,
  `SV_type` varchar(20) NOT NULL,
  `SV_time` datetime NOT NULL,
  `SV_rank` int(11) DEFAULT '0',
  `SV_theme` varchar(200) DEFAULT NULL,
  `SV_dataMode` varchar(20) DEFAULT NULL,
  `SV_accounts` varchar(200) DEFAULT NULL,
  `SV_state` int(11) DEFAULT '1',
  PRIMARY KEY (`SV_ID`),
  UNIQUE KEY `IM_ID` (`SV_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_service`
--

LOCK TABLES `ot_service` WRITE;
/*!40000 ALTER TABLE `ot_service` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_settings`
--

DROP TABLE IF EXISTS `ot_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_settings`
--

LOCK TABLES `ot_settings` WRITE;
/*!40000 ALTER TABLE `ot_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_shop_image`
--

DROP TABLE IF EXISTS `ot_shop_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_shop_image` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `imagepath` varchar(20) DEFAULT NULL,
  `addtime` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_shop_image`
--

LOCK TABLES `ot_shop_image` WRITE;
/*!40000 ALTER TABLE `ot_shop_image` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_shop_image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_shop_leibie`
--

DROP TABLE IF EXISTS `ot_shop_leibie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_shop_leibie` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(50) DEFAULT '' COMMENT '分类名称',
  `addtime` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_shop_leibie`
--

LOCK TABLES `ot_shop_leibie` WRITE;
/*!40000 ALTER TABLE `ot_shop_leibie` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_shop_leibie` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_shop_orderform`
--

DROP TABLE IF EXISTS `ot_shop_orderform`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_shop_orderform` (
  `id` int(255) unsigned NOT NULL AUTO_INCREMENT,
  `user` varchar(30) DEFAULT NULL,
  `project` varchar(30) DEFAULT NULL,
  `count` int(11) DEFAULT NULL,
  `sumprice` decimal(10,2) NOT NULL,
  `addtime` varchar(30) DEFAULT NULL,
  `zt` int(1) NOT NULL DEFAULT '0',
  `address` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_shop_orderform`
--

LOCK TABLES `ot_shop_orderform` WRITE;
/*!40000 ALTER TABLE `ot_shop_orderform` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_shop_orderform` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_shop_project`
--

DROP TABLE IF EXISTS `ot_shop_project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_shop_project` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) unsigned DEFAULT NULL,
  `name` varchar(60) DEFAULT NULL,
  `title` varchar(60) DEFAULT NULL,
  `content` text,
  `old_price` int(11) DEFAULT '0',
  `price` int(10) DEFAULT '0',
  `zt` enum('0','1','2','3','4') DEFAULT NULL,
  `imagepath` text,
  `addtime` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=64 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_shop_project`
--

LOCK TABLES `ot_shop_project` WRITE;
/*!40000 ALTER TABLE `ot_shop_project` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_shop_project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_shopsj`
--

DROP TABLE IF EXISTS `ot_shopsj`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_shopsj` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sjmc` varchar(255) DEFAULT NULL,
  `jyxm` varchar(255) DEFAULT NULL,
  `lxfs` varchar(255) DEFAULT NULL,
  `dz` varchar(255) DEFAULT NULL,
  `slt` varchar(255) DEFAULT NULL,
  `content` longtext,
  `user` varchar(255) DEFAULT NULL,
  `zt` int(15) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `leixin` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_shopsj`
--

LOCK TABLES `ot_shopsj` WRITE;
/*!40000 ALTER TABLE `ot_shopsj` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_shopsj` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_system`
--

DROP TABLE IF EXISTS `ot_system`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_system` (
  `SYS_ID` int(11) NOT NULL AUTO_INCREMENT,
  `SYS_theme` varchar(100) DEFAULT NULL,
  `SYS_address` varchar(200) DEFAULT NULL,
  `SYS_postCode` varchar(50) DEFAULT NULL,
  `SYS_contact` varchar(50) DEFAULT '',
  `SYS_mobile` varchar(50) DEFAULT '',
  `SYS_mail` varchar(80) DEFAULT NULL,
  `SYS_phone` varchar(50) DEFAULT NULL,
  `SYS_hotPhone` varchar(50) DEFAULT NULL,
  `SYS_fax` varchar(50) DEFAULT NULL,
  `SYS_qq` varchar(30) DEFAULT NULL,
  `SYS_banquan` varchar(100) DEFAULT NULL,
  `SYS_seoTitle` varchar(300) DEFAULT '',
  `SYS_seoWord` text,
  `SYS_seoDesc` text,
  `SPS_smtpHost` varchar(80) DEFAULT NULL,
  `SPS_sendMail` varchar(80) DEFAULT NULL,
  `SPS_sendPwd` varchar(80) DEFAULT NULL,
  `SPS_giveMail` varchar(80) DEFAULT NULL,
  `a_ztj` decimal(15,4) NOT NULL DEFAULT '0.0000' COMMENT '直推荐奖',
  `a_ztj2` decimal(15,4) NOT NULL DEFAULT '0.0000' COMMENT '间推奖',
  `a_ztj3` decimal(15,4) NOT NULL DEFAULT '0.0000' COMMENT '间间推奖',
  `a_bdj` decimal(15,4) NOT NULL DEFAULT '0.0000' COMMENT '报单奖',
  `a_ld8` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `a_ld9` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `a_ld10` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `a_kd_zsb` decimal(15,4) NOT NULL DEFAULT '0.0000' COMMENT '钻石币开单数量',
  `a_sxf` decimal(15,4) NOT NULL DEFAULT '0.0000' COMMENT '交易大厅手续费',
  `a_btbjg` decimal(15,4) NOT NULL DEFAULT '0.0000' COMMENT '比特币价格',
  `a_fxzl` decimal(15,4) NOT NULL DEFAULT '0.0000' COMMENT '发行总量',
  `a_fuhuo` decimal(15,4) NOT NULL DEFAULT '0.0000' COMMENT '复活费用',
  `a_mrfh_cj` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `a_ybfxsl` decimal(15,4) NOT NULL DEFAULT '0.0000' COMMENT '銀幣發行數量',
  `a_zsbfxsl` decimal(15,4) NOT NULL,
  `a_ybhuilv` decimal(15,6) NOT NULL,
  `a_zsbhuilv` decimal(15,6) NOT NULL,
  `a_bdzxds` decimal(15,4) NOT NULL,
  `zt` int(8) NOT NULL DEFAULT '0',
  `toggleshop` varchar(15) DEFAULT '0',
  PRIMARY KEY (`SYS_ID`),
  KEY `SYS_postCode` (`SYS_postCode`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_system`
--

LOCK TABLES `ot_system` WRITE;
/*!40000 ALTER TABLE `ot_system` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_system` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_taobaoset`
--

DROP TABLE IF EXISTS `ot_taobaoset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_taobaoset` (
  `TBS_ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `TBS_state` tinyint(1) DEFAULT '1',
  `TBS_appkey` varchar(30) DEFAULT '',
  `TBS_secret` varchar(150) DEFAULT '',
  PRIMARY KEY (`TBS_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_taobaoset`
--

LOCK TABLES `ot_taobaoset` WRITE;
/*!40000 ALTER TABLE `ot_taobaoset` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_taobaoset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_tgbz`
--

DROP TABLE IF EXISTS `ot_tgbz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_tgbz` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `zffs1` int(8) NOT NULL DEFAULT '0' COMMENT '微信支付',
  `zffs2` int(8) NOT NULL DEFAULT '0' COMMENT '支付宝支付',
  `zffs3` int(8) NOT NULL DEFAULT '0' COMMENT '银行卡支付',
  `jb` decimal(15,0) NOT NULL DEFAULT '0' COMMENT '排单额',
  `zt` int(8) NOT NULL DEFAULT '0',
  `user` varchar(255) DEFAULT NULL,
  `qr_zt` int(255) DEFAULT '0',
  `user_tjr` varchar(255) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `user_nc` varchar(255) DEFAULT NULL,
  `cf_ds` int(8) NOT NULL DEFAULT '0',
  `jycg_ds` int(8) NOT NULL DEFAULT '0',
  `yid` int(11) DEFAULT NULL,
  `yjb` decimal(15,0) NOT NULL DEFAULT '0',
  `zhh` int(2) NOT NULL DEFAULT '0',
  `zhh1` int(2) NOT NULL DEFAULT '0',
  `date1` datetime DEFAULT NULL COMMENT '冻结',
  `date2` datetime DEFAULT NULL COMMENT '显示',
  `yfk` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=990059 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_tgbz`
--

LOCK TABLES `ot_tgbz` WRITE;
/*!40000 ALTER TABLE `ot_tgbz` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_tgbz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_topup`
--

DROP TABLE IF EXISTS `ot_topup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_topup` (
  `TU_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '用户订单表',
  `TU_type` varchar(30) DEFAULT '' COMMENT '订单类型',
  `TU_time` datetime DEFAULT NULL COMMENT '添加时间',
  `TU_revTime` datetime DEFAULT NULL COMMENT '状态修改时间',
  `TU_userID` int(11) NOT NULL DEFAULT '0' COMMENT '用户ID',
  `TU_money` float(11,2) DEFAULT '0.00' COMMENT '充值金额',
  `TU_payment` varchar(30) DEFAULT '' COMMENT '充值方式',
  `TU_userNote` varchar(250) DEFAULT '' COMMENT '会员留言',
  `TU_adminNote` varchar(250) DEFAULT '' COMMENT '管理员备注',
  `TU_status` tinyint(1) DEFAULT '0' COMMENT '到款状态',
  PRIMARY KEY (`TU_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_topup`
--

LOCK TABLES `ot_topup` WRITE;
/*!40000 ALTER TABLE `ot_topup` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_topup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_turn`
--

DROP TABLE IF EXISTS `ot_turn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_turn` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `consume` int(11) DEFAULT '0' COMMENT '抽奖单次消耗',
  `switch` tinyint(1) DEFAULT '1' COMMENT '  抽奖开关',
  `turn_num` char(200) DEFAULT '' COMMENT ' 奖励内容',
  `turn_v` char(200) DEFAULT '' COMMENT '概率',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_turn`
--

LOCK TABLES `ot_turn` WRITE;
/*!40000 ALTER TABLE `ot_turn` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_turn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_turn_log`
--

DROP TABLE IF EXISTS `ot_turn_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_turn_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT '0' COMMENT '用户id',
  `consume` int(11) DEFAULT '0' COMMENT ' 消耗',
  `reward_id` int(11) DEFAULT '0' COMMENT '几等奖',
  `reward_num` int(11) DEFAULT '0' COMMENT '奖励金额',
  `addtime` int(11) DEFAULT '0' COMMENT '获奖时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_turn_log`
--

LOCK TABLES `ot_turn_log` WRITE;
/*!40000 ALTER TABLE `ot_turn_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_turn_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_upfile`
--

DROP TABLE IF EXISTS `ot_upfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_upfile` (
  `UF_ID` int(11) NOT NULL AUTO_INCREMENT,
  `UF_time` datetime DEFAULT NULL,
  `UF_type` varchar(25) DEFAULT NULL,
  `UF_oldName` varchar(80) DEFAULT NULL,
  `UF_name` varchar(50) DEFAULT NULL,
  `UF_ext` varchar(10) DEFAULT NULL,
  `UF_size` int(11) DEFAULT '0',
  `UF_width` int(11) DEFAULT '0',
  `UF_height` int(11) DEFAULT '0',
  `UF_isThumb` smallint(6) DEFAULT '0',
  `UF_thumbName` varchar(50) DEFAULT NULL,
  `UF_useNum` mediumint(9) DEFAULT '0',
  PRIMARY KEY (`UF_ID`),
  UNIQUE KEY `UF_ID` (`UF_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=952 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_upfile`
--

LOCK TABLES `ot_upfile` WRITE;
/*!40000 ALTER TABLE `ot_upfile` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_upfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_user`
--

DROP TABLE IF EXISTS `ot_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_user` (
  `UE_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '商城用户注册登录表',
  `UE_img` varchar(60) DEFAULT '' COMMENT '用户头像',
  `UE_account` varchar(60) NOT NULL DEFAULT '' COMMENT '登录账号',
  `UE_accName` varchar(60) DEFAULT NULL COMMENT '推荐人账号',
  `sfjl` int(15) NOT NULL DEFAULT '0',
  `zcr` varchar(60) NOT NULL DEFAULT '' COMMENT '推荐人',
  `UE_Faccount` varchar(30) DEFAULT '0' COMMENT '父账号',
  `UE_verMail` varchar(60) NOT NULL DEFAULT '' COMMENT '验证邮箱',
  `UE_check` smallint(1) DEFAULT '0' COMMENT '是否验证，0-未验证，1-邮箱验证，2-手机验证',
  `check_time` varchar(100) DEFAULT NULL,
  `UE_actiCode` varchar(10) DEFAULT '' COMMENT '邮箱/手机验证激活码',
  `UE_password` varchar(80) DEFAULT '' COMMENT '用户密码',
  `UE_regTime` datetime DEFAULT NULL COMMENT '注册时间',
  `UE_regIP` varchar(60) DEFAULT '',
  `UE_nowTime` text COMMENT '当前登录时间',
  `UE_nowIP` varchar(60) DEFAULT '' COMMENT '当前登录IP',
  `UE_lastTime` text COMMENT '最近一次登录时间',
  `UE_lastIP` varchar(60) DEFAULT '' COMMENT '最近一次录陆IP',
  `UE_logNum` int(11) DEFAULT '0' COMMENT '用户登录次数',
  `UE_status` smallint(1) DEFAULT '1' COMMENT '用户状态，0-正常，1-禁用',
  `UE_level` int(1) DEFAULT '0' COMMENT '会员等级',
  `UE_note` text COMMENT '管理页备注信息',
  `UE_integral` decimal(15,0) DEFAULT '0' COMMENT '当前账户积分余额',
  `UE_money` decimal(15,0) DEFAULT '0' COMMENT '当前帐户余额（静态钱包）',
  `UE_sum` float(11,0) DEFAULT '0' COMMENT '当前账户总消费数',
  `UE_info` text COMMENT '用户信息',
  `UE_secpwd` varchar(80) DEFAULT NULL COMMENT '二级密码',
  `UE_theme` varchar(60) DEFAULT '',
  `UE_tjx` varchar(60) DEFAULT NULL COMMENT '推荐奖总和',
  `UE_ldx` varchar(60) DEFAULT NULL COMMENT '领导奖',
  `UE_mailCheck` varchar(30) DEFAULT '0' COMMENT '邮箱验证0未验证，1验证了',
  `UE_sfz` varchar(20) DEFAULT NULL COMMENT '身份证',
  `UE_qq` varchar(20) DEFAULT NULL,
  `UE_phone` varchar(20) DEFAULT NULL COMMENT '手机',
  `UE_truename` varchar(60) DEFAULT NULL COMMENT '真实名字',
  `UE_activeTime` text COMMENT '激活时间',
  `UE_stop` tinyint(2) DEFAULT '1' COMMENT '停止分红，0标志停止分红，1标志正常分红',
  `UE_toActive` tinyint(2) DEFAULT '0' COMMENT '1表示已经被用过去激活新增帐号',
  `UE_drpd` varchar(60) DEFAULT NULL,
  `zbqx` int(5) NOT NULL DEFAULT '0' COMMENT '是否充许其它账号转币',
  `zbzh` varchar(60) DEFAULT NULL,
  `ybhe` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `zsbhe` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `email` varchar(60) DEFAULT NULL,
  `jihuouser` varchar(60) NOT NULL,
  `btbdz` varchar(60) NOT NULL DEFAULT '0',
  `pin` varchar(255) DEFAULT NULL COMMENT '激活码',
  `mz` varchar(255) DEFAULT NULL,
  `xin` varchar(255) DEFAULT NULL,
  `weixin` varchar(255) DEFAULT NULL,
  `zfb` varchar(255) DEFAULT NULL,
  `yhmc` varchar(255) DEFAULT NULL COMMENT '银行名称',
  `zhxm` varchar(255) DEFAULT NULL COMMENT '开户地址',
  `yhzh` varchar(255) DEFAULT NULL COMMENT '银行卡号',
  `tz_leiji` decimal(15,0) NOT NULL DEFAULT '0',
  `date_leiji` datetime DEFAULT NULL,
  `jl_he` decimal(15,0) NOT NULL DEFAULT '0' COMMENT '动态钱包',
  `tj_he` decimal(15,0) NOT NULL DEFAULT '0',
  `pp_user` varchar(255) DEFAULT NULL,
  `tx_leiji` decimal(15,0) NOT NULL,
  `tx_date` datetime DEFAULT NULL,
  `shop_money` int(11) DEFAULT '0',
  `cold` int(2) DEFAULT '0' COMMENT '冻结状态（0，未冻结   1，已冻结）',
  `cold_time` datetime DEFAULT NULL COMMENT '冻结时间',
  `UE_regTime1` datetime DEFAULT NULL,
  `cold_type` int(1) DEFAULT '0' COMMENT '冻结原因（1,72小时不排单2,48小时不打款3,24小时不收款）',
  `sfz_img_url` text,
  `li_lv` varchar(255) DEFAULT '0' COMMENT '排单金额',
  PRIMARY KEY (`UE_ID`),
  UNIQUE KEY `anme` (`UE_account`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_user`
--

LOCK TABLES `ot_user` WRITE;
/*!40000 ALTER TABLE `ot_user` DISABLE KEYS */;
INSERT INTO `ot_user` VALUES (1,'','15737168980','15937178918',0,'15937178918','0','',1,NULL,'','e10adc3949ba59abbe56e057f20f883e','2017-07-11 17:38:37','1.193.126.112',NULL,'',NULL,'',0,0,0,NULL,0,0,0,NULL,'e10adc3949ba59abbe56e057f20f883e','小余',NULL,NULL,'0','412159166952525149',NULL,NULL,'小余',NULL,1,0,NULL,0,NULL,0.0000,0.0000,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'郑州',NULL,'6221504910002558888',0,NULL,0,0,NULL,0,NULL,0,0,NULL,'2017-07-11 17:38:37',0,'Uploads/Pic/2017-07-11/59649c9da33fc.jpg',NULL),(2,'','15136272070','15737168980',0,'15737168980','0','',1,NULL,'','e10adc3949ba59abbe56e057f20f883e','2017-07-11 18:23:18','115.60.190.208',NULL,'',NULL,'',0,0,0,NULL,0,0,0,NULL,'e10adc3949ba59abbe56e057f20f883e','王坤',NULL,NULL,'0','41018419963256456',NULL,NULL,'王坤',NULL,1,0,NULL,0,NULL,0.0000,0.0000,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'郑州',NULL,'6221504910003856469',0,NULL,0,0,NULL,0,NULL,0,0,NULL,'2017-07-11 18:23:18',0,'Uploads/Pic/2017-07-11/5964a71645007.png',NULL);
/*!40000 ALTER TABLE `ot_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_user_jj`
--

DROP TABLE IF EXISTS `ot_user_jj`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_user_jj` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(255) DEFAULT NULL,
  `r_id` varchar(255) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `zt` int(8) NOT NULL DEFAULT '0',
  `jb` decimal(15,0) DEFAULT NULL,
  `tgbz_id` int(11) NOT NULL,
  `jianglilixi` varchar(50) DEFAULT '',
  `zhh` int(2) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3113 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_user_jj`
--

LOCK TABLES `ot_user_jj` WRITE;
/*!40000 ALTER TABLE `ot_user_jj` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_user_jj` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_user_jl`
--

DROP TABLE IF EXISTS `ot_user_jl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_user_jl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(255) DEFAULT NULL,
  `r_id` int(15) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `zt` int(8) NOT NULL DEFAULT '0',
  `jb` decimal(15,0) DEFAULT NULL,
  `ds` varchar(255) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `jj` decimal(10,0) DEFAULT NULL,
  `leixin` int(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=900 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_user_jl`
--

LOCK TABLES `ot_user_jl` WRITE;
/*!40000 ALTER TABLE `ot_user_jl` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_user_jl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_userget`
--

DROP TABLE IF EXISTS `ot_userget`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_userget` (
  `UG_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '商城用户注册登录表',
  `UG_account` varchar(60) DEFAULT '' COMMENT '登录账号',
  `UG_type` varchar(60) DEFAULT '' COMMENT '奖金分类',
  `UG_integral` decimal(15,4) DEFAULT '0.0000' COMMENT '当前账户种子币余额',
  `UG_money` varchar(255) DEFAULT '0.0000' COMMENT '当前帐户金币余额',
  `UG_getTime` datetime DEFAULT NULL COMMENT '结算时间',
  `UG_allGet` decimal(20,0) DEFAULT NULL COMMENT '用户密码',
  `UG_balance` decimal(20,0) DEFAULT NULL COMMENT '当前账户余额',
  `UG_regIP` varchar(30) DEFAULT '',
  `UG_dataType` varchar(10) DEFAULT '' COMMENT '分红类型',
  `UG_note` text COMMENT '金币获取说明',
  `UG_othraccount` varchar(60) DEFAULT NULL COMMENT '推荐帐号/开单帐号',
  `yb` decimal(15,2) DEFAULT '0.00',
  `ybhe` decimal(15,2) DEFAULT NULL,
  `zsb` decimal(15,2) DEFAULT NULL,
  `zsbhe` decimal(15,2) DEFAULT NULL,
  `yb1` decimal(15,2) DEFAULT NULL,
  `zsb1` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`UG_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=8889 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_userget`
--

LOCK TABLES `ot_userget` WRITE;
/*!40000 ALTER TABLE `ot_userget` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_userget` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_userget1`
--

DROP TABLE IF EXISTS `ot_userget1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_userget1` (
  `UG_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '商城用户注册登录表',
  `UG_account` varchar(60) DEFAULT '' COMMENT '登录账号',
  `UG_type` varchar(60) DEFAULT '' COMMENT '奖金分类',
  `UG_integral` decimal(15,4) DEFAULT '0.0000' COMMENT '当前账户种子币余额',
  `UG_money` varchar(255) DEFAULT '0.0000' COMMENT '当前帐户金币余额',
  `UG_getTime` datetime DEFAULT NULL COMMENT '结算时间',
  `UG_allGet` decimal(20,0) DEFAULT NULL COMMENT '用户密码',
  `UG_balance` decimal(20,0) DEFAULT NULL COMMENT '当前账户余额',
  `UG_regIP` varchar(30) DEFAULT '',
  `UG_dataType` varchar(10) DEFAULT '' COMMENT '分红类型',
  `UG_note` text COMMENT '金币获取说明',
  `UG_othraccount` varchar(60) DEFAULT NULL COMMENT '推荐帐号/开单帐号',
  `jd_date` datetime DEFAULT NULL COMMENT '解冻时间',
  `dtzt` int(2) DEFAULT '0',
  `UG_qrTime` datetime DEFAULT NULL,
  PRIMARY KEY (`UG_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=5421 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_userget1`
--

LOCK TABLES `ot_userget1` WRITE;
/*!40000 ALTER TABLE `ot_userget1` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_userget1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_usergroup`
--

DROP TABLE IF EXISTS `ot_usergroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_usergroup` (
  `UG_ID` int(11) NOT NULL AUTO_INCREMENT,
  `UG_time` datetime DEFAULT NULL,
  `UG_name` varchar(50) DEFAULT NULL,
  `UG_rightStr` longtext,
  `UG_note` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`UG_ID`),
  KEY `UG_ID` (`UG_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_usergroup`
--

LOCK TABLES `ot_usergroup` WRITE;
/*!40000 ALTER TABLE `ot_usergroup` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_usergroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_userinfo`
--

DROP TABLE IF EXISTS `ot_userinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_userinfo` (
  `UI_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '用户详细信息表',
  `UI_userID` int(11) DEFAULT '0' COMMENT '用户表ID',
  `UI_time` datetime DEFAULT NULL COMMENT '添加时间',
  `UI_revTime` datetime DEFAULT NULL COMMENT '修改时间',
  `UI_realName` varchar(30) DEFAULT '' COMMENT '真实姓名',
  `UI_payaccount` varchar(30) DEFAULT NULL COMMENT '收款账号信息',
  `UI_payStyle` varchar(10) DEFAULT NULL COMMENT '收款方式',
  `UI_isindex` smallint(1) DEFAULT NULL COMMENT '是否设为默认',
  `UI_opendress` varchar(30) DEFAULT NULL COMMENT '开户行',
  PRIMARY KEY (`UI_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_userinfo`
--

LOCK TABLES `ot_userinfo` WRITE;
/*!40000 ALTER TABLE `ot_userinfo` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_userinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_userlevel`
--

DROP TABLE IF EXISTS `ot_userlevel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_userlevel` (
  `UL_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '会员等级划分表',
  `UL_theme` varchar(200) DEFAULT '' COMMENT '等级名称',
  `UL_price` float(11,2) DEFAULT '0.00' COMMENT '消费金额',
  `UL_cheap` float(11,2) DEFAULT '10.00' COMMENT '折扣',
  `UL_time` datetime DEFAULT NULL COMMENT '添加时间',
  PRIMARY KEY (`UL_ID`),
  UNIQUE KEY `IM_ID` (`UL_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_userlevel`
--

LOCK TABLES `ot_userlevel` WRITE;
/*!40000 ALTER TABLE `ot_userlevel` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_userlevel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_wallet`
--

DROP TABLE IF EXISTS `ot_wallet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ot_wallet` (
  `user_id` varchar(20) NOT NULL,
  `money` int(200) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_wallet`
--

LOCK TABLES `ot_wallet` WRITE;
/*!40000 ALTER TABLE `ot_wallet` DISABLE KEYS */;
/*!40000 ALTER TABLE `ot_wallet` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-07-12 16:42:49
